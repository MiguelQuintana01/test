import numpy as np


def generate_circle_coords(radius, num_points, center=np.array([0, 0]), start_radian=0, round_digits=None):
    """
    Generate coordinates of points on a circle.

    Parameters:
    - radius (float): The radius of the circle.
    - num_points (int): The number of points to generate on the circle.
    - center (numpy.ndarray): A 1D array with the x and y coordinates of the circle's center.
    - start_radian (float): The starting radian offset from the x-axis.
    - round_digits (int or None): The number of decimal places to round the coords. If None, don't round.

    Returns:
    - numpy.ndarray: An array where each row is an (x, y) coordinate pair.
    """
    # Calculate angles for the points, starting from start_radian
    angles = np.linspace(0, 2 * np.pi, num_points, endpoint=False) + start_radian

    # Calculate x and y coordinates
    x_coords = radius * np.cos(angles)
    y_coords = radius * np.sin(angles)

    # Stack x and y coordinates to create a 2D array
    coords = np.vstack((x_coords, y_coords)).T

    # Shift coordinates by the center point
    coords += center

    # Round coordinates if round_digits is not None
    if round_digits is not None:
        coords = np.round(coords, decimals=round_digits)

    return coords


def generate_grid_points_in_rectangle(corner1, corner2, n):
    """
    Generates `n` approximately evenly spaced points inside a rectangle.

    Args:
        corner1 (array-like): The (x, y) coordinates of the first corner of the rectangle.
        corner2 (array-like): The (x, y) coordinates of the opposite corner of the rectangle.
        n (int): The approximate total number of points to generate. Actual number will be adjusted to fit a grid.

    Returns:
        np.ndarray: An array of points shaped approximately (sqrt(n), sqrt(n)), each inside the rectangle.
    """
    corner1 = np.asarray(corner1)
    corner2 = np.asarray(corner2)

    # Extract coordinates
    x_min, x_max = np.sort([corner1[0], corner2[0]])
    y_min, y_max = np.sort([corner1[1], corner2[1]])

    # Calculate number of points along x and y that closely matches target n total points
    grid_dim = int(np.sqrt(n))

    # Create grid of points
    x_values = np.linspace(x_min, x_max, grid_dim)
    y_values = np.linspace(y_min, y_max, grid_dim)

    # Form meshgrid and reshape into a Nx2 array
    x_grid, y_grid = np.meshgrid(x_values, y_values)
    points = np.column_stack([x_grid.ravel(), y_grid.ravel()])

    return points


def get_bounding_box_coordinates(coordinates):
    """Calculates the bounding box coordinates for a set of points.

    Args:
        coordinates (array-like): An array-like object containing points (x, y) that define the region.

    Returns:
        ndarray: A ndarray containing two coords:
            - max_coordinates: Array containing the maximum x and y coordinates.
            - min_coordinates: Array containing the minimum x and y coordinates.
    """
    coordinates = np.asarray(coordinates)
    min_coordinates = np.array([np.min(coordinates[:, 0]), np.min(coordinates[:, 1])])
    max_coordinates = np.array([np.max(coordinates[:, 0]), np.max(coordinates[:, 1])])

    return np.array([max_coordinates, min_coordinates])


def get_middle_point(coord1, coord2):
    # Ensure inputs are numpy arrays
    coord1 = np.asarray(coord1)
    coord2 = np.asarray(coord2)

    # Calculate the middle point
    midpoint = (coord1 + coord2) / 2

    return midpoint


def get_vector_from_points_2d(point, new_position):
    """
    Calculate the vector from a given point to a new position in 2D space using NumPy.

    Parameters:
    - point: A NumPy array representing the original point [x1, y1].
    - new_position: A NumPy array representing the new position [x2, y2].

    Returns:
    - A NumPy array representing the vector [dx, dy].
    """
    point = np.asarray(point)
    new_position = np.asarray(new_position)

    # Calculate the vector
    vector = new_position - point

    return vector