import numpy as np
from src.autoplace.utilities.generate_cords import get_bounding_box_coordinates


def find_other_corners(corner1, corner2):
    """
    Given two opposite corners of a rectangle, find and return the other two corners.

    Parameters:
    corner1 (ndarray): Coordinates of the first corner (x1, y1).
    corner2 (ndarray): Coordinates of the opposite corner (x2, y2).

    Returns:
    tuple: Coordinates of the other two corners.
    """
    # Ensure inputs are numpy arrays
    corner1 = np.array(corner1)
    corner2 = np.array(corner2)

    # Extract x and y coordinates
    x1, y1 = corner1
    x2, y2 = corner2

    # Calculate the other two corners
    other_corner1 = np.array([x1, y2])
    other_corner2 = np.array([x2, y1])

    return other_corner1, other_corner2


def points_within_bounding_box(points, shape_points):
    """Check if points are within the bounding box of a given shape.

    Args:
        points (array-like): An array of points, where each point is represented by its coordinates (x, y).
        shape_points (any): The shape whose bounding box will be calculated.

    Returns:
        np.ndarray: A boolean array indicating whether each point is inside the bounding box.
    """
    if points.size < 1:
        return np.array([])
    # Convert the input points to a NumPy array
    points_array = np.asarray(points)

    # Retrieve the bounding box coordinates for the given shape
    bounding_box_coords = get_bounding_box_coordinates(shape_points)

    # Create masks for x-coordinates and y-coordinates to check if they lie within the bounding box
    x_within_bounds = np.logical_and(
        points_array[:, 0] < bounding_box_coords[0][0],
        points_array[:, 0] > bounding_box_coords[1][0]
    )

    y_within_bounds = np.logical_and(
        points_array[:, 1] < bounding_box_coords[0][1],
        points_array[:, 1] > bounding_box_coords[1][1]
    )

    # Return a boolean array indicating if the points are inside the bounding box
    return np.logical_and(x_within_bounds, y_within_bounds)