import numpy as np
import matplotlib.pyplot as plt


def show_coordinates(coords):
    """
    Displays a scatter plot of xy coordinates.

    Parameters:
    coords (ndarray): A NumPy array with shape (n, 2), where each row represents an (x, y) coordinate.

    Returns:
    None
    """
    if not isinstance(coords, np.ndarray):
        raise TypeError("Input must be a numpy ndarray.")

    if coords.shape[1] != 2:
        raise ValueError("Input ndarray must have shape (n, 2) where n is the number of points.")

    # Extract x and y coordinates
    x_values = coords[:, 0]
    y_values = coords[:, 1]

    # Create a scatter plot
    plt.scatter(x_values, y_values, c='b', marker='o', label='Coordinates')

    # Set plot labels and title
    plt.xlabel('X-axis')
    plt.ylabel('Y-axis')
    plt.title('XY Coordinates Scatter Plot')
    plt.legend()

    # Display grid
    plt.grid(True)

    # Show plot
    plt.show()
