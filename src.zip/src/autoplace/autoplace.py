import numpy as np

from src.autoplace.utilities.bounding_box import points_within_bounding_box
from src.autoplace.utilities.generate_cords import get_bounding_box_coordinates, generate_grid_points_in_rectangle, \
    get_vector_from_points_2d, get_middle_point, generate_circle_coords


def get_coordinate_mask(a, b):
    """
    Returns a boolean mask indicating whether each coordinate in `b` is present in `a`.

    Args:
        a (ndarray): An array of coordinates with shape (m, 2), where m is the number of coordinates in `a`.
        b (ndarray): An array of coordinates with shape (n, 2), where n is the number of coordinates in `b`.

    Returns:
        ndarray: A boolean array of length n, where True indicates the coordinate in `b` is present in `a`.
    """
    # Expand dimensions to allow for comparison
    a_expanded = a[:, np.newaxis, :]  # Expand `a` along the second dimension
    b_expanded = b[np.newaxis, :, :]  # Expand `b` along the first dimension

    # Compare coordinates
    comparison = (a_expanded == b_expanded).all(axis=2)

    # A coordinate in `b` matches if there is any `True` in its column
    mask = comparison.any(axis=0)

    return mask


def place_circle(shape, used_points, target_point, increment_radius=5):
    """
    Places a grid of points around a target point, adjusting based on existing points to avoid overlap.

    Args:
        shape (object): An object representing the shape for which the bounding box coordinates are to be calculated.
        used_points (np.ndarray): An array of points already in use, to avoid overlapping with new points.
        target_point (tuple): The coordinates (x, y) of the initial target point.
        increment_radius (int, optional): The increment used to expand the radius when searching for a non-overlapping position. Defaults to 5.

    Returns:
        tuple: The first element is a new target point (circle center) that does not overlap with existing points.
              The second element is a new grid of points around this target point.
    """
    bounding_box_coords = get_bounding_box_coordinates(shape)
    initial_grid = generate_grid_points_in_rectangle(bounding_box_coords[0], bounding_box_coords[1], 2024)
    initial_grid = np.round(initial_grid, 0)

    bounding_box_grid = get_bounding_box_coordinates(initial_grid)
    grid_center = get_middle_point(bounding_box_grid[0], bounding_box_grid[1])

    translation_vector = get_vector_from_points_2d(grid_center, target_point)
    translated_grid = initial_grid + translation_vector
    overlap_mask = points_within_bounding_box(used_points, translated_grid)

    if not np.any(overlap_mask) or overlap_mask.size < 1:
        return target_point, translated_grid
    else:
        radius = 0
        while True:
            radius += increment_radius
            circle_coords = generate_circle_coords(radius, 100, target_point, round_digits=0)
            unique_circle_coords = np.unique(circle_coords, axis=0)

            non_overlapping_points = unique_circle_coords[~get_coordinate_mask(used_points, unique_circle_coords)]
            for non_overlap_point in non_overlapping_points:
                translation_vector = get_vector_from_points_2d(grid_center, non_overlap_point)
                adjusted_grid = initial_grid + translation_vector
                overlap_mask = points_within_bounding_box(used_points, adjusted_grid)

                if not np.any(overlap_mask):
                    return non_overlap_point, adjusted_grid