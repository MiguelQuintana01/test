from src.autoplace.autoplace import place_circle
from src.autoplace.dev_tools import show_coordinates
from src.autoplace.utilities.generate_cords import *

circle = generate_circle_coords(radius=5, num_points=4, round_digits=2, center=np.array([5,5]))
new_point, new_grid = place_circle(circle, generate_grid_points_in_rectangle([100, 100], [-100, -100], 10000), np.array([0,0]))
print("hola")
show_coordinates(np.vstack([generate_grid_points_in_rectangle([100, 100], [-100, -100], 10000), new_grid]))