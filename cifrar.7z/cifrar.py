import base64
import os
from Cryptodome.Cipher import AES
from Cryptodome.Util.Padding import pad, unpad


class AES256Cipher:
    def __init__(self, key):
        if isinstance(key, str):
            key = key.encode('utf-8')
        if len(key) != 32:
            raise ValueError(f"La llave debe tener 32 bytes para AES-256: {len(key)}")
        self.key = key

    def encrypt(self, plaintext):
        # Convertir texto plano a bytes
        plaintext_bytes = plaintext.encode('utf-8')

        # Rellenar el texto para que sea múltiplo del tamaño de bloque
        padded_bytes = pad(plaintext_bytes, AES.block_size)

        # Generar vector de inicialización (IV)
        iv = os.urandom(16)

        # Crear cifrador
        cipher = AES.new(self.key, AES.MODE_CBC, iv)

        # Cifrar los datos
        ciphertext = cipher.encrypt(padded_bytes)

        # Combinar IV + texto cifrado y codificar en base64
        return base64.b64encode(iv + ciphertext).decode('utf-8')

    def decrypt(self, encrypted_text):
        # Decodificar de base64
        raw_data = base64.b64decode(encrypted_text)

        # Separar IV y texto cifrado
        iv = raw_data[:16]
        ciphertext = raw_data[16:]

        # Crear cifrador
        cipher = AES.new(self.key, AES.MODE_CBC, iv)

        # Descifrar
        decrypted_padded = cipher.decrypt(ciphertext)

        # Eliminar el relleno
        decrypted = unpad(decrypted_padded, AES.block_size)

        return decrypted.decode('utf-8')


# Clave debe ser de 32 bytes (256 bits)
# key = os.urandom(32)  # Ejemplo generando una llave aleatoria

# Crear instancia
# cipher = AES256Cipher(key)
#
# # Cifrar texto
# texto_original = "Texto secreto importante"
# texto_cifrado = cipher.encrypt(texto_original)
# print(f"Texto cifrado: {texto_cifrado}")
#
# # Descifrar texto
# texto_descifrado = cipher.decrypt(texto_cifrado)
# print(f"Texto descifrado: {texto_descifrado}")


