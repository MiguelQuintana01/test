import socket

from cifrar import AES256Cipher
def leer_y_limpiar_txt(ruta_archivo):
    """
    Lee el contenido de un archivo .txt y lo deja en blanco.

    Parámetros:
        ruta_archivo (str): Ruta del archivo .txt a modificar.

    Retorna:
        str: Contenido original del archivo antes de limpiarlo.
              Retorna None si hay errores.
    """
    try:
        # 1. Leer el contenido original
        with open(ruta_archivo, 'r', encoding='utf-8') as archivo:
            contenido_original = archivo.read()

        # 2. Limpiar el archivo (sobreescribir con cadena vacía)
        with open(ruta_archivo, 'w', encoding='utf-8') as archivo:
            archivo.write('')

        return contenido_original

    except FileNotFoundError:
        print(f"Error: El archivo '{ruta_archivo}' no existe.")
    except Exception as e:
        print(f"Error inesperado: {e}")
    return None

def enviar_mensaje(cypher: AES256Cipher):
    # Configuración del cliente
    host = '176.57.184.244'  # IP del servidor
    port = 8085  # Puerto del servidor

    # Crear un socket TCP
    socket_cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Conectar al servidor
    socket_cliente.connect((host, port))

    # Enviar el mensaje
    mensaje = input("Ingrese el mensaje: ")

    cypher_mensaje = cypher.encrypt(mensaje)
    socket_cliente.sendall(cypher_mensaje.encode('utf-8'))

    # Recibir la respuesta
    respuesta = socket_cliente.recv(1024).decode('utf-8')
    respuesta_cypher = cypher.decrypt(respuesta)
    print("Respuesta del servidor: {}".format(respuesta_cypher))

    # Cerrar la conexión
    socket_cliente.close()

if __name__ == "__main__":
    key = leer_y_limpiar_txt("./conf.json")
    cypher = AES256Cipher(key)
    while True:
        try:
            enviar_mensaje(cypher)
        except:
            pass
