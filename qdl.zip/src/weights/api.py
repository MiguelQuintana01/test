import numpy as np
from fastapi import APIRouter, Form

from src.file.file import download_csv_weights, get_weight, verify_csv_file, get_all_measures

api = APIRouter()


@api.post("")
def get_weight_api(start: int = Form(default=0), end: int = Form(default=4102444800)):
    verify_csv_file()

    history_dates, history_weights = get_all_measures()

    if history_dates.size > 0:
        mask = np.logical_and(start <= history_dates, history_dates <= end)
        history_dates = history_dates[mask]
        history_weights = history_weights[mask]

    dict_measures = {"fecha": history_dates.tolist(),
                     "peso": history_weights.tolist()}
    return dict_measures


@api.post("/download-csv")
def download_csv(start: int = Form(0), end: int = Form(4102444800), gmt: int = Form(0)):
    return download_csv_weights(start, end, gmt)
